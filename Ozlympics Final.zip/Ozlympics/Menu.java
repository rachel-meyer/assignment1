/**
 * The Menu class prints the menu for the Ozlympic program. It converts the user
 * choice from the string to integer and runs the Ozlympic program based on 
 * the user's choice. 
 */

package Ozlympics;
import java.util.Scanner;

public class Menu {
    
    private int optionConvert;
    private Game game;
    private Scanner scan = new Scanner(System.in);
       
    
    /*Runs all the methods in the Menu class.*/
    public void runMenu() {
        printmenu();
        convert();
        menuOption();
    }
    
    
    /*Prints the menu.*/
    public final void printmenu() {
        System.out.println("Ozlympic Games");
        System.out.println("============================================");
        System.out.println("1. Set up a game");
        System.out.println("2. Play a game");
        System.out.println("3. Display the final results of all games");
        System.out.println("4. Display the points of all atheletes");
        System.out.println("5. Exit"+"\n");
        System.out.println("Enter an option:_");
    }
          
    
    /*Converts the user's choice from String to Integer and handles user
     * input errors.
     */
    public void convert() {
        String userChoice = scan.next();
        
        try {
            optionConvert=Integer.parseInt(userChoice);
	    while (!((optionConvert>=1)&&(optionConvert<=5))) {
                System.err.println("Oops! Please choose an option"
                	           + " between 1 and 5"+ "\n");
		printmenu();
		convert();
	    }
	} catch (NumberFormatException e) {
            System.err.println("Oops! Please choose an option"
            	               + " between 1 and 5"+ "\n");
	    printmenu();
	    convert();
	}
    }
	 
    
    /*Runs the rest of the Ozlympic program based on the user choice.*/
    public void menuOption() {
        switch (optionConvert) {
	case 1:
	    Game.getAllGames().add(new Game());
	    game = Game.getAllGames().get(Game.getAllGames().size()-1);
	    game.setUpGame();
	    runMenu();
	    break;
	
	case 2:
	    if(Game.getAllGames().size()==0) {
		System.out.println("Sorry you need to set up a game before"
		          + " you can play a game");
	    } else { game = Game.getAllGames().get(Game.getAllGames().size()-1);
		game.playGame();
		runMenu();
		break;
	    }

	case 3:
	    Official o1 = new Official();
	    o1.summariseGames();
	    runMenu();
	    break;
	
	case 4:
	    Official o2 = new Official();
	    o2.summarisePoints(); 
	    runMenu();
	    break;
	
	case 5:
	    System.out.println("Thanks for playing! See you next time :-)");
	    System.exit(0);
	    break;
        }
    }  
    
}





/**
 * Cyclist is a child class of Athlete used to overwrite the compete method.
 * Cyclist instances will be created when the user sets up a Cycling event. 
 */

package Ozlympics;
import java.util.concurrent.ThreadLocalRandom;

public class Cyclist extends Athlete {
    
    
    public Cyclist(String id, String name, int age, 
	           String state, String type, int points){
	super(id, name, age, state, type, points);
    }
    
    public void compete() {
	setResult(ThreadLocalRandom.current().nextInt(500, 800 + 1));
    }
    
}
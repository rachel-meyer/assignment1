/**
 * The Official class contains attributes and a constructor to support creation of
 * an Official object.
 * Most of the attributes are common its super class, Participant. 
 * The allOfficials ArrayList is for keeping all of the officials' details.
 * Is also contains methods that are the role of the official in the Ozlympic games:
 * 1/ To summarise the results of all the games including the referee's name
 * 2/ To summarise the current total points of all the athletes competiting in the games.
 */

package Ozlympics;
import java.util.ArrayList;

public class Official extends Participant {
    
    private static ArrayList<Official> allOfficials  = new ArrayList<Official>();
    

    public Official (String id, String name, int age,
	             String state, String type) {
	super(id, name, age, state, type);	
    }
    
    public Official() {
	
    }
    
    public static ArrayList<Official> getAllOfficals(){
	return allOfficials;
    }
    
    
    /* Summarises the results of all the games run so far*/
    public void summariseGames(){
	for (Game g: Game.getAllGames()){
	    if(g.getSetUp().getCompetitors().get(0).getGamePoints()==0) {
		continue;
	    }
	    System.out.println("Results for event "+g.getSetUp().getEventID()
	    			   +" are as follows:");
	    	for (int i=0; i<g.getSetUp().getCompetitors().size(); i++){
		    System.out.println("Place #"+(i+1)+" "
		        +g.getSetUp().getCompetitors().get(i).getId()+" "
			+g.getSetUp().getCompetitors().get(i).getName()+", "
			+g.getSetUp().getCompetitors().get(i).getResult()+" seconds, "+
			+g.getSetUp().getCompetitors().get(i).getGamePoints()+" points");
	    	}    
         System.out.println("The referee was "+g.getSetUp().getReferee().getName()+"\n");
	} 
    }
       
       
    /*Summarises the total points of all the Athletes so far*/
    public void summarisePoints(){
	System.out.println("Total points of all Athletes are as follows: ");
	for (Athlete a: Athlete.getAllAthletes())
	    System.out.println("ID:"+a.getId()+", Name:"+a.getName()
	     	    	       +", Points:"+a.getTotalPoints());
	     }
	
}

/**
 * Participant is an abstract class set up to support creation of 
 * two classes: Athlete and Official. 
 * It contains attributes that are common to both child classes.
 * Is contains constructors to support setting up the Athlete
 * and Official objects. 
 */

package Ozlympics;

public abstract class Participant {

    private String id;
    private String name;
    private int age;
    private String state;
    private String type;
    
    public Participant (String id, String name, int age,
	    		String state, String type) {
	this.id=id;
	this.name=name;
	this.age=age;
	this.state=state;
	this.type=type;
    }
      
    
    public Participant() {

     }
    
    public String getId() {
	return id;
    }
    
    public String getName() {
	return name;
    }
   
    public int getAge() {
	return age;
    }
    
    public String getState() {
	return state;
    }

    public String getType() {
	return type;
    }

    public void setType(String type) {
	this.type = type;
    }
  

}

/**
 * The Prediction class is used to set and check the predicted winner for
 * the game that is selected by the user to be played in the PlayGame class.
 */

package Ozlympics;

import java.util.Scanner;

public class Prediction {
    
    private Athlete winnerPrediction;
    private Scanner scan = new Scanner(System.in);
    private String userChoice;
    private int winnerConvert;
    
    
    /* Asks the user to predict the winner of the selected game.
     * Displays the competitors to choose from and calls method
     * to convert prediction.
     */
    public void predictWinner(Game gameSelectPlay) {
    	System.out.println("Here are the competitors for the "
    		    	  +gameSelectPlay.getSetUp().getGameType()+ " race");
        System.out.println("Choose who you think will win.");
        for (int i=0; i<gameSelectPlay.getSetUp().getCompetitors().size(); i++) {
            System.out.println(i+1+" "+gameSelectPlay.getSetUp().
        		       getCompetitors().get(i).getId()
        		       +" "+gameSelectPlay.getSetUp().
        		       getCompetitors().get(i).getName());
        }
	convertPrediction(gameSelectPlay);
    }
    
    
    /* Converts user's prediction choice to integer and deals with input errors*/
    public void convertPrediction(Game gameSelectPlay) {
        userChoice = scan.next();
        try {
            winnerConvert=Integer.parseInt(userChoice)-1;
            while (!((winnerConvert>=0)&&(winnerConvert<gameSelectPlay.
		      getSetUp().getCompetitors().size()))) {
	    	System.err.println("Oops! Please choose an option between 1 and "
	         		   +gameSelectPlay.getSetUp().
	         		   getCompetitors().size()+"\n");
		predictWinner(gameSelectPlay);
            }
	} catch (NumberFormatException e) {
	    System.err.println("Oops! Please choose an option between 1 and "
				+gameSelectPlay.getSetUp().
				getCompetitors().size()+"\n");
	    predictWinner(gameSelectPlay);   
	}
    	for (int i=0; i<gameSelectPlay.getSetUp().getCompetitors().size();i++) {
    	    if (winnerConvert==i) {
    	        winnerPrediction=gameSelectPlay.getSetUp().
    	        	         getCompetitors().get(i); 
    	    }
    	}
     }
    
    
    /*Displays the user's prediction choice*/
    public void confirmPrediction() {
	System.out.println("Your prediction for the win is "
		   + winnerPrediction.getId()+" " 
		   +winnerPrediction.getName());				
    }
    
    
    /*Checks the user's prediction and prints congrats message if the 
     * prediction is correct. 
     */
    public void checkPrediction(Game gameSelectPlay) {
	 if((gameSelectPlay.getSetUp().getCompetitors().get(0).getId().
            equals(winnerPrediction.getId()))) {
	     System.out.println("Congratulations "+winnerPrediction.getId()
		                +" "+winnerPrediction.getName()+ " won the "
		                + gameSelectPlay.getSetUp().getGameType()+" race!");
	     System.out.println("Your prediction was correct!");	     	     
	 }	 	
    }


}

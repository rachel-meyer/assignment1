/**
 * The SetUpGame class is used to setup a game including:
 * 1/ Selecting the event type(Swimming, Cycling, or Swimming)
 * 2/ Randomly assigning the number of athletes in the game
 * 3/ Canceling the game if there aren't enough athletes to compete
 * 4/ Assigning a referee for the game
 * 5/ Assigning the competitors for the game
 */

package Ozlympics;
import java.util.*;

public class SetUpGame {

    private int eventConvert;
    private String eventID;
    private String gameType;
    private Scanner scan = new Scanner(System.in);
    private int athleteNum;
    private Official referee; 
    private ArrayList<Athlete> competitors  = new ArrayList<Athlete>();
    private static int eventNum;
    
    
    
    public static int getEventNum() {
	return eventNum;
    }

    public static void setEventNum() {
	eventNum++;
    }

    public String getGameType() {
	return gameType;
    }
    
    public String getEventID() {
	return eventID;
    }
        
    public int getAthleteNum() {
	    return athleteNum;
    }
      
    public Official getReferee() {
	return referee;
    }
    
    public ArrayList<Athlete> getCompetitors() {
	return competitors;
    }
    

    /* User chooses which kind of event s/he wants to setup. User input is a
     * a string and converted to integer. Method handles input errors.
     */  
    public void selectEvent() throws NumberFormatException {
	boolean okay=false;
	String eventChoice="0";
	
	do {
	    System.out.println("Please choose event 1, 2 or 3:");
	    System.out.println("1. Swimming"+"\n"+"2. Cycling"+"\n"
	                      +"3. Running");
	    try {
		eventChoice = scan.next();	
		eventConvert=Integer.parseInt(eventChoice);
		while (!((eventConvert>=1)&&(eventConvert<=3))) {
		    System.err.println("Oops! Please select a number between 1"
		    	               + " and 3"+ "\n");
		    selectEvent();
		}
		okay=true;
	    } catch (NumberFormatException e) {
		System.err.println("Oops! Please select a number between 1"
				   + " and 3"+ "\n");
	    }
       } while (!okay);
    }

    /*Creates a new event based on the user's choice.*/
    public void setEventType() {
	if (eventConvert==1) { 
	    gameType="Swimming";
	} else if (eventConvert==2) {
	    gameType="Cycling";
	} else if (eventConvert==3) {
	    gameType="Running";
	}
    }
    
    /*Randomly assigns the number of athletes (up to 8) to compete. 
     * Cancels the game if there aren't enough athletes (less than 4).
     */
    public void setAthleteNum() {
	athleteNum = new Random().nextInt(9);
 	System.out.println("Looking to see how many athletes are available..."); 	
 	if (athleteNum < 4){
            System.out.println("Sorry there were not enough athletes "
 			       + "to compete");
 	    System.out.println("This event has to be cancelled :-(");
 	    cancelGame();	
 	    Menu menu = new Menu();
 	    menu.runMenu();
 	} else { 
 	    System.out.println(athleteNum + " athletes are available to compete");
 	    System.out.println("The following athletes will be competing:");
 	}   
    }
    
    
    /*Cancels the game if there aren't enough athletes to compete.*/
    public void cancelGame() {
	Game.getAllGames().remove(Game.getAllGames().size()-1);
    } 
    
    
    /*Creates event ID for the game.*/ 
    public String setEventID() {
	setEventNum();
	eventID=String.valueOf(gameType+eventNum);
	return eventID;
    }  
    

    /*Randomly assigns a referee from the allOfficials ArrayList.*/
    public void setReferee() {
	Collections.shuffle(Official.getAllOfficals());
	for(int i=0; i<Official.getAllOfficals().size(); i++)
	    referee=Official.getAllOfficals().get(0);
    }
    
    
    /*Suffles the allAthlete ArrayList, then iterates through the array to get
     *  the right kind of athletes to compete based on the event type.
     */
    public void setCompetitors() {	
        Collections.shuffle(Athlete.getAllAthletes());
	switch (gameType) {
	case "Swimming": 
	    for (Athlete c: Athlete.getAllAthletes()) 	   
		if (((c.getType().equals("Swimming"))
		   ||(c.getType().equals("Super Athlete")))
		   &&(competitors.size()!=athleteNum)) {
		    competitors.add(new Swimmer(c.getId(), c.getName(),
		                   c.getAge(),c.getState(), c.getType(),
		                   c.getTotalPoints())); 
		    }	
	    break;
        
	case "Cycling":
	    for (Athlete c: Athlete.getAllAthletes()) 	   
		if (((c.getType().equals("Cycling"))
		   ||(c.getType().equals("Super Athlete")))
		   &&(competitors.size()!=athleteNum)) {
		    competitors.add (new Cyclist(c.getId(), c.getName(),
			             c.getAge(),c.getState(), c.getType(),
			             c.getTotalPoints())); 
		    }
	    break;
            
	case "Running":	
	    for (Athlete c: Athlete.getAllAthletes()) 	   
		if (((c.getType().equals("Running"))
		   ||(c.getType().equals("Super Athlete")))
		   &&(competitors.size()!=athleteNum)) {
		    competitors.add(new Sprinter(c.getId(), c.getName(),
		             c.getAge(),c.getState(), c.getType(),
		             c.getTotalPoints())); 
		    }
	    break;       
	}   
	System.out.println("Your competitors are: ");
	for (Athlete c: competitors)
	    System.out.println("ID:"+c.getId()+", "+"Name:"+c.getName());    	    
    }

}

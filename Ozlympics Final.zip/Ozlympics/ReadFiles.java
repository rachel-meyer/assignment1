/**
 * The ReadFiles class reads the data text files for Athletes and Officials and 
 * adds the data to the relevant ArrayList. 

 */

package Ozlympics;

import java.io.*;

public class ReadFiles {
    
    private final String AthletesFile = "/Users/Rachel/Documents/workspace/"
    	                                + "Advanced Programming/src/Ozlympics/"
    	                                + "AthleteData.txt";
    private final String OfficialsFile = "/Users/Rachel/Documents/workspace/"
    	                                 + "Advanced Programming/src/Ozlympics/"
    	                                 + "OfficialsData.txt";
    
    
    //read in the Athlete data
    public void setAllAthletes(){
	try {
	    BufferedReader br = new BufferedReader(new FileReader(AthletesFile));
	    String line=null;
	    while((line=br.readLine())!=null){
		String a[]=line.split("\t");
	    	Athlete.getAllAthletes().add(new Athlete(a[0],a[1],
	    		Integer.parseInt(a[2]),a[3],a[4],Integer.parseInt(a[5])));
	    }
	    br.close();
	} catch (FileNotFoundException e) {
	    System.out.println("The file cannot be found");
	} catch (IOException e) {
	    System.out.println("There was an error with loading the file");
	} catch (Exception e) {
	    System.out.println("There was an error");
	}	
    }
    
	 
    //read in the Officials data
    public void setOfficials(){
	try {
	    BufferedReader br = new BufferedReader(new FileReader(OfficialsFile));
	    String line=null;    
	    while((line=br.readLine())!=null){
		String a[]=line.split("\t");
		Official.getAllOfficals().add(new Official(a[0],a[1],
			Integer.parseInt(a[2]),a[3],a[4]));
	    }	    
	    br.close();   
	} catch (FileNotFoundException e) {
	    System.out.println("The file cannot be found");
	} catch (IOException e) {
	    System.out.println("There was an error with loading the file");
	} catch (Exception e) {
	    System.out.println("There was an error");
	}
    }
    
}

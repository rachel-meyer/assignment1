/**
 * The PlayGame class:
 * 1/ allows the user to select which game they wish to play
 *    in the game ArrayList,
 * 2/ asks the user to predict the winner of the selected game,
 * 3/ runs the game
 * 4/ sorts the competitors based on the results of the game from best to worst
 * 5/ assigns points for the game
 * 6/ displays results of the game
 * 7/ checks if the user's prediction is correct and produces congrats message
 * 8/ updates the Athlete ArrayList to add the athletes' points for the game 
 */
package Ozlympics;

import java.util.*;

public class PlayGame {
    
    private Scanner scan = new Scanner(System.in);
    private Game gameSelectPlay;
    private Prediction predict = new Prediction();
    private String gameChoice;
    private int gameChoiceConvert;
    
    public Game getGameSelectPlay() {
	return gameSelectPlay;
    }

   
   /*Runs through the methods for the PlayGame class and the Prediction class*/
   public void playGame() {
       selectGame();
       predict.predictWinner(gameSelectPlay);
       predict.confirmPrediction();
       compete();
       sortResults();
       assignPoints();
       displayResults();
       predict.checkPrediction(gameSelectPlay);
       updateAthleteData();
   }
   
   
    /* Lists all the available games for user selection.
     * Calls method to convert user selection
     */
    public void selectGame() {	
	System.out.println("Please select a game to play");
	    for (int i = 0; i<Game.getAllGames().size(); i++) {
		SetUpGame k=Game.getAllGames().get(i).getSetUp();
		System.out.println((i+1)+" - Event ID:"+k.getEventID());
		    for(int j=0; j<k.getCompetitors().size(); j++) {
                        System.out.println("Competitors:"+ k.getCompetitors().
                        	          get(j).getId()+" "+k.getCompetitors().
                        	          get(j).getName());
		    }
		System.out.println("Referee:"+Game.getAllGames().get(i).getSetUp().
			            getReferee().getName()+"\n");
	    }
	    convertGameSelection();
    }
    
    
    /*Convert user's game selection and deals with input errors*/
    public void convertGameSelection() {
	gameChoice = scan.next();
	try {  
	    gameChoiceConvert=(Integer.parseInt(gameChoice))-1;
	    	while (!((gameChoiceConvert>=0)&&
	    	         (gameChoiceConvert<Game.getAllGames().size()))) {
	    	    System.err.println("Oops! Please choose an option between 1 and "+
	    		               Game.getAllGames().size() + "\n");
	    	    selectGame();
	    	}
	} catch (NumberFormatException e) {
    	      System.err.println("Oops! Please choose an option between 1 and "+
    		                  Game.getAllGames().size() + "\n");
    	      selectGame();
	}
	gameSelectPlay = Game.getAllGames().get(gameChoiceConvert);
    }
    
    
    /*Runs the selected game by calling the compete method (declared in
     * Athlete class). Sets the game points to 0 beforehand,
     * in case the game has already been run before. 
     */
    public void compete() {
 	for (Athlete c: gameSelectPlay.getSetUp().getCompetitors()) {
 	    c.setGamePoints(0);
 	    c.compete();
 	}
    }

    
    /*Sorts the competitors based on their results.*/
     public void sortResults() {
         Collections.sort((List<Athlete>) gameSelectPlay.getSetUp().
        	           getCompetitors(), new Comparator<Athlete>() {
        public int compare(Athlete result1, Athlete result2) {
 	    return result1.getResult().compareTo(result2.getResult());
 	}
 	}); 
      }
     
     
    /*Assigns points based on the results for the game and updates Athletes'
     * total points. 
     */
    public void assignPoints() {
        for (int i=0; i<gameSelectPlay.getSetUp().getCompetitors().size(); i++) {
            if(i==0) {
                gameSelectPlay.getSetUp().getCompetitors().get(i).
                setGamePoints(5);
             } else if (i==1) {
                 gameSelectPlay.getSetUp().getCompetitors().get(i).
                 setGamePoints(2);
             } else if (i==2) {
                 gameSelectPlay.getSetUp().getCompetitors().get(i).
                 setGamePoints(1);
 	     } else if (i>2) { 
 		 gameSelectPlay.getSetUp().getCompetitors().get(i).
                 setGamePoints(0);
 	    }
        }
        for (Athlete c : gameSelectPlay.getSetUp().getCompetitors()) {
            c.setTotalPoints();
        }
    }
    

     /*Prints out the results for the selected game.*/
    public void displayResults() {
        System.out.println("Results for event "+gameSelectPlay.getSetUp().
        	           getEventID()+" are as follows:");
   	for (int i=0; i<gameSelectPlay.getSetUp().getCompetitors().size(); i++) {
   	    ArrayList<Athlete> j = gameSelectPlay.getSetUp().getCompetitors();
   	    System.out.println("Place #"+(i+1)+" "+j.get(i).getId()+" "
   	                       +j.get(i).getName()+", "
   		               +j.get(i).getResult()+" seconds, "
   		               +j.get(i).getGamePoints()+" points");
      	} 
     }
       
 
     /*Updates the allAthletes ArrayList to add game points to total points.*/
     public void updateAthleteData() {
	 for(Athlete c: gameSelectPlay.getSetUp().getCompetitors()) {
	     for(int i=0; i<Athlete.getAllAthletes().size();i++) {
		 if(c.getId().equals(Athlete.getAllAthletes().get(i).getId())) {
		     Athlete.getAllAthletes().set(i,c);
		 }
	     }
	 }
     }
     
}

/**
 * The Ozlympic program is for running a set of games called the "Ozlympic Games"
 * The Ozlympic class is the main start up class.
 * The program can:
 * Allow the user to set up a game
 * Allow the user to select a game to run (or re-run)
 * Allow the user to predict the winner of the game
 * Run a game and award points for the top 3 competitors
 * Display a congratulation message if the user prediction is correct.
 * Display the final result of all games including the name of the referee for each game.
 * Display the points of athletes.
 * 
 * @author Rachel Meyer - s3403023
 */

package Ozlympics;

public class Ozlympic {

    public static void main(String[] args) {
    ReadFiles file = new ReadFiles();
    file.setAllAthletes();
    file.setOfficials();
    Menu menu = new Menu();
    menu.runMenu();
    
    }
                
}



    

    

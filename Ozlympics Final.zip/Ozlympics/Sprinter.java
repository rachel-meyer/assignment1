/**
 * Sprinter is a child class of Athlete used to overwrite the compete method.
 * Sprinter instances will be created when the user sets up a Running event. 
 */

package Ozlympics;
import java.util.concurrent.ThreadLocalRandom;

public class Sprinter extends Athlete {
     
    public Sprinter (String id, String name, int age,
	    	     String state, String type, int points){
	super(id, name, age, state, type, points);
    }
   
    public void compete() {
	setResult(ThreadLocalRandom.current().nextInt(10, 20 + 1));
    }
  
    
}
/**
 * The Athlete class contains attributes and a constructor to support creation of an Athlete object.
 * Most of the attributes are common its super class, Participant. 
 * The allAthletes ArrayList is for keeping all of the athletes' details.
 */

package Ozlympics;
import java.util.ArrayList;

public class Athlete extends Participant {
    
    private int totalPoints;
    private int gamePoints;
    private int result;
    private static ArrayList<Athlete> allAthletes  = new ArrayList<Athlete>();


    public Athlete (String id, String name, int age, 
	            String state, String type, int points){
	super(id, name, age, state, type);
	this.totalPoints=points;
    }
    
    public static ArrayList<Athlete> getAllAthletes(){
	return allAthletes;
    }

    public int getTotalPoints() {
	return totalPoints;
    }

    public void setTotalPoints() {
	totalPoints = totalPoints+gamePoints;	
    }

    public void compete() {
    }
    
    public Integer getResult() {
	return result;
    }

    public int getGamePoints() {
	return gamePoints;
    }

    public void setGamePoints(int gamePoints) {
	this.gamePoints = gamePoints;
    }

    public void setResult(int result) {
	this.result=result;
    }
    
    
}  
   
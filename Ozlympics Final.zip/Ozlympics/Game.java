/**
 * The Game class sets up a game and plays a game based on user choices
 * The game is added to the game ArrayList. 
 */

package Ozlympics;
import java.util.ArrayList;

public class Game{
    
    private static ArrayList<Game> allGames = new ArrayList<Game>();
    private SetUpGame setup;
    private PlayGame play;
  

    public SetUpGame getSetUp(){
	return setup;
    }
    
    public PlayGame getPlay() {
	return play;
    }
    
    
    public static ArrayList<Game> getAllGames() {
	return allGames;
    }
   
    /*Sets up a game. See class for details.*/
    public void setUpGame(){
        setup = new SetUpGame();
	setup.selectEvent();
	setup.setEventType();
	setup.setAthleteNum();
	setup.setEventID();
	setup.setReferee();
	setup.setCompetitors();
    }
    
    
    /* Plays a game that is stored in the game ArrayList based on user's 
     * choices. See class for details.
     */
    public void playGame() {
	play = new PlayGame();
	play.playGame();
	}
     
}
